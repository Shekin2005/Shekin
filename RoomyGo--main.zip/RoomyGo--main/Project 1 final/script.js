// Hamburger menu toggle
function toggleMenu() {
  const navLinks = document.getElementById('navLinks');
  navLinks.classList.toggle('active');
}

// Scroll to section
function scrollToSection(sectionId) {
  const section = document.getElementById(sectionId);
  section.scrollIntoView({ behavior: 'smooth' });
  document.getElementById('navLinks').classList.remove('active');
}

// Sign In Modal
function openSignIn() {
  document.getElementById('signinModal').style.display = 'flex';
}
function closeSignIn() {
  document.getElementById('signinModal').style.display = 'none';
}

// Sign Up Modal
function openSignup() {
  closeSignIn();
  document.getElementById('signupModal').style.display = 'flex';
}
function closeSignup() {
  document.getElementById('signupModal').style.display = 'none';
}

// Verification Modal
function openVerify() {
  closeSignIn();
  document.getElementById('verifyModal').style.display = 'flex';
}
function closeVerify() {
  document.getElementById('verifyModal').style.display = 'none';
}

// Close modal on clicking outside
window.onclick = function(event) {
  const modals = ['signinModal','signupModal','verifyModal'];
  modals.forEach(id => {
    const modal = document.getElementById(id);
    if(event.target === modal) {
      modal.style.display = 'none';
    }
  });
}

// --- Sign Up ---
document.getElementById('signupForm').addEventListener('submit', function(e){
  e.preventDefault();
  const email = document.getElementById('signupEmail').value;
  const password = document.getElementById('signupPassword').value;

  if(localStorage.getItem(email)){
    alert("User already exists. Please Sign In.");
    openSignIn();
    closeSignup();
  } else {
    localStorage.setItem(email, password);
    alert("Sign Up successful! Please Sign In.");
    openSignIn();
    closeSignup();
  }
});

// --- Sign In ---
document.getElementById('signinForm').addEventListener('submit', function(e){
  e.preventDefault();
  const email = document.getElementById('signinEmail').value;
  const password = document.getElementById('signinPassword').value;

  const savedPassword = localStorage.getItem(email);
  if(savedPassword){
    if(savedPassword === password){
      alert("Sign In successful! Redirecting to Selections Page...");
      window.location.href = "selections.html"; // redirect to selections page
    } else {
      alert("Incorrect password. Please verify your email to reset password.");
      openVerify();
    }
  } else {
    alert("Email not found. Please Sign Up.");
    openSignup();
  }
});

// --- Verification Code (simulate) ---
let correctCode = Math.floor(100000 + Math.random()*900000);
console.log("Verification code (for testing):", correctCode);

function verifyCode(){
  const userCode = document.getElementById('verificationCode').value;
  const newPass = document.getElementById('newPassword').value;
  const email = document.getElementById('signinEmail').value;

  if(userCode == correctCode){
    localStorage.setItem(email, newPass);
    alert("Password reset successful! Please Sign In again.");
    closeVerify();
    openSignIn();
  } else {
    alert("Incorrect verification code.");
  }
// Open/close modals
function openSignIn(){document.getElementById('signinModal').style.display='flex';}
function closeSignIn(){document.getElementById('signinModal').style.display='none';}
function openSignup(){closeSignIn();document.getElementById('signupModal').style.display='flex';}
function closeSignup(){document.getElementById('signupModal').style.display='none';}
function openVerify(){closeSignIn();document.getElementById('verifyModal').style.display='flex';}
function closeVerify(){document.getElementById('verifyModal').style.display='none';}

// Sign Up
document.getElementById('signupForm').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const email = document.getElementById('signupEmail').value;
  const password = document.getElementById('signupPassword').value;

  const res = await fetch('http://localhost:3000/signup',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({email,password})
  });
  const data = await res.json();
  alert(data.message);
  if(res.ok){closeSignup();openSignIn();}
});

// Sign In
document.getElementById('signinForm').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const email = document.getElementById('signinEmail').value;
  const password = document.getElementById('signinPassword').value;

  const res = await fetch('http://localhost:3000/signin',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({email,password})
  });
  const data = await res.json();
  alert(data.message);
  if(res.ok){
    window.location.href = 'selections.html';
  } else if(data.message.includes('Verification')){
    openVerify();
  } else {
    openSignup();
  }
});

// Verify and reset password
document.getElementById('verifyForm')?.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const email = document.getElementById('signinEmail').value;
  const code = document.getElementById('verificationCode').value;
  const newPassword = document.getElementById('newPassword').value;

  const res = await fetch('http://localhost:3000/verify',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({email,code,newPassword})
  });
  const data = await res.json();
  alert(data.message);
  if(res.ok){closeVerify();openSignIn();}
});
}

// Hamburger menu toggle (already present)
function toggleMenu() {
  const navLinks = document.getElementById('navLinks');
  navLinks.classList.toggle('active');
}

// --- Profile Modal ---
function openProfile(){
  document.getElementById('profileModal').style.display = 'flex';

  // Load existing profile
  const name = localStorage.getItem('profileName') || '';
  const location = localStorage.getItem('profileLocation') || '';
  const picture = localStorage.getItem('profilePicture') || '';
  const ratings = localStorage.getItem('profileRatings') || '⭐⭐⭐⭐☆';

  document.getElementById('profileName').value = name;
  document.getElementById('profileLocation').value = location;
  document.getElementById('profileRatings').value = ratings;

  if(picture){
    // show preview if needed
    console.log('Profile picture loaded');
  }
}
function closeProfile(){ document.getElementById('profileModal').style.display='none'; }

// Save profile
document.getElementById('profileForm').addEventListener('submit', function(e){
  e.preventDefault();
  const name = document.getElementById('profileName').value;
  const location = document.getElementById('profileLocation').value;
  const pictureInput = document.getElementById('profilePicture');

  localStorage.setItem('profileName', name);
  localStorage.setItem('profileLocation', location);

  // Save picture as base64
  if(pictureInput.files.length > 0){
    const reader = new FileReader();
    reader.onload = function(){
      localStorage.setItem('profilePicture', reader.result);
    }
    reader.readAsDataURL(pictureInput.files[0]);
  }

  alert('Profile saved successfully!');
  closeProfile();
}
);

// Close modal on outside click
window.onclick = function(event){
  const modal = document.getElementById('profileModal');
  if(event.target === modal){
    modal.style.display='none';
  }

  // When page loads, check if a section is requested via hash (#)
  window.addEventListener("DOMContentLoaded", () => {
    const hash = window.location.hash;

    if (hash === "#find-room") {
      document.getElementById("r-find-room").checked = true;
    } else if (hash === "#find-roommate") {
      document.getElementById("r-find-roommate").checked = true;
    } else if (hash === "#ad-room") {
      document.getElementById("r-ad-room").checked = true;
    } else if (hash === "#ad-roommate") {
      document.getElementById("r-ad-roommate").checked = true;
    }
  });
}
