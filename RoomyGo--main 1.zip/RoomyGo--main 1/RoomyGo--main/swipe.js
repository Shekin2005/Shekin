document.addEventListener("DOMContentLoaded", () => {
  const cardContainer = document.getElementById("cardContainer");
  const skipBtn = document.getElementById("skipBtn");
  const saveBtn = document.getElementById("saveBtn");
  const favBtn = document.getElementById("favBtn");

  let items = [];
  let mode = "rooms";

  // ------------------ SAMPLE DATA ------------------
  items = [
    {
      "id": "room-101",
      "title": "Cozy Room near Campus",
      "location": "Wolfville, Linden Ave  • 5 min walk",
      "price": "$650 / month",
      "roommates": "2 roommates • mixed",
      "description": "A bright and cozy room ideal for students. Comes fully furnished with a study desk, closet space, and fast Wi-Fi. The kitchen and laundry are shared with two clean and friendly roommates. Only a short 5-minute walk to Acadia University.",
      "imageUrl": "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.1.0"
    },
    {
      "id": "room-102",
      "title": "Basement Suite",
      "location": "Kentville, Downtown • 25 min bus",
      "price": "$550 / month",
      "roommates": "1 roommate • female",
      "description": "Private basement suite ideal for someone who likes peace and privacy. Fully furnished with a bed, mini-fridge, and study table. Utilities and Wi-Fi included. Close to grocery stores, bus stops, and cafés.",
      "imageUrl": "https://images.unsplash.com/photo-1615800002234-05c4d488696c?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0"
    }
    // Add more rooms if you want
  ];

  // ------------------ PAGE TITLES ------------------
  const urlParams = new URLSearchParams(window.location.search);
  mode = urlParams.get("mode") || "rooms";

  const pageTitle = document.getElementById("pageTitle");
  const pageSubtitle = document.getElementById("pageSubtitle");

  if (mode === "roommates") {
    pageTitle.textContent = "Swipe Roommates";
    pageSubtitle.textContent = "Find your perfect roommate match";
  } else {
    pageTitle.textContent = "Swipe Rooms";
    pageSubtitle.textContent = "Swipe to like or skip rooms";
  }

  // ------------------ CREATE CARDS ------------------
  function createCards() {
    cardContainer.innerHTML = "";

    if (items.length === 0) {
      cardContainer.innerHTML = "<h2>No matches found</h2>";
      return;
    }

    items.forEach((item, index) => {
      const card = document.createElement("div");
      card.classList.add("card");
      card.dataset.index = index;

      card.innerHTML = `
        <div class="card-content">
          <img src="${item.imageUrl}" class="room-image">
          <h2>${item.title}</h2>
          <p>${item.location}</p>
          <h3 class="price">${item.price}</h3>
          <p>${item.description.substring(0, 80)}...</p>
        </div>
      `;

      cardContainer.appendChild(card);
      enableDrag(card);
    });
  }

  // ------------------ GET TOP CARD ------------------
  function getTopCard() {
    const cards = document.querySelectorAll(".card");
    return cards[cards.length - 1];
  }

  // ------------------ DRAG-TO-SWIPE ------------------
  function enableDrag(card) {
    let startX = 0;
    let currentX = 0;
    let dragging = false;

    card.addEventListener("mousedown", e => {
      dragging = true;
      startX = e.clientX;
      card.style.transition = "none";
    });

    window.addEventListener("mousemove", e => {
      if (!dragging) return;
      currentX = e.clientX - startX;
      card.style.transform = `translateX(${currentX}px) rotate(${currentX / 20}deg)`;
    });

    window.addEventListener("mouseup", () => {
      if (!dragging) return;
      dragging = false;
      card.style.transition = "0.3s ease";

      if (currentX > 120) return performSwipe("like");
      if (currentX < -120) return performSwipe("skip");

      card.style.transform = "translateX(0) rotate(0)";
    });
  }

  // ------------------ SWIPE ANIMATION ------------------
  function performSwipe(direction) {
    const card = getTopCard();
    if (!card) return;

    const index = Number(card.dataset.index);
    const item = items[index];

    const movement = direction === "like" ? 1400 : -1400;
    const rotate = direction === "like" ? 18 : -18;

    card.style.transform = `translateX(${movement}px) rotate(${rotate}deg)`;
    card.style.opacity = "0";

    setTimeout(() => {
      if (direction === "like") saveItem(item);
      card.remove();
      if (!document.querySelector(".card")) cardContainer.innerHTML = "<h2>No more matches!</h2>";
    }, 260);
  }

  // ------------------ SAVE TO LOCAL STORAGE ------------------
  function saveItem(item) {
    let saved = JSON.parse(localStorage.getItem("savedItems")) || [];
    saved.push(item);
    localStorage.setItem("savedItems", JSON.stringify(saved));
    alert(`${item.title} saved! ❤️`);
  }

  // ------------------ BUTTONS ------------------
  skipBtn.addEventListener("click", () => performSwipe("skip"));
  saveBtn.addEventListener("click", () => performSwipe("like"));
  favBtn.addEventListener("click", () => window.location.href = "favourites.html");

  // ------------------ INIT ------------------
  createCards();
});

