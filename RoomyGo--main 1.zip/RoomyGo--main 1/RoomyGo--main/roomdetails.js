document.addEventListener("DOMContentLoaded", () => {
    const room = JSON.parse(localStorage.getItem("selectedRoom"));

    if (!room) {
        document.body.innerHTML = "<h2>No room found.</h2>";
        return;
    }

    document.getElementById("detailsImage").src = room.image;
    document.getElementById("detailsTitle").textContent = room.title;
    document.getElementById("detailsLocation").textContent = room.location;
    document.getElementById("detailsPrice").textContent = room.price;
    document.getElementById("detailsDescription").textContent = room.description;

    document.getElementById("contactBtn").addEventListener("click", () => {
        alert(
            "Contact Landlord:\n\nEmail: landlord@example.com\nPhone: +1 555-123-4567\n\n(This can later be real)"
        );
    });
});
