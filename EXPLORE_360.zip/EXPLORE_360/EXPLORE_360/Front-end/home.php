<!DOCTYPE html>
<html lang="en">
<?php
$con = mysqli_connect("localhost", "establishments_user", "passw0rd", "establishments_db");

// Check connection
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

// Initialize search query
$search = "";
$result = null;
if (isset($_GET['search']) && !empty($_GET['search'])){
    $search = $_GET['search'];

    $sql_statement = "SELECT establishment_name, rating, establishment_address, category FROM establishment WHERE establishment_name LIKE ? OR rating LIKE ? OR establishment_address LIKE ? OR category LIKE ? ORDER BY rating DESC LIMIT 100";

    $stmt = mysqli_prepare($con, $sql_statement);
    $search_param = '%' . $search . '%';
    mysqli_stmt_bind_param($stmt, 'ssss', $search_param, $search_param, $search_param, $search_param);

    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
}
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wolfville Guide</title>
    <link rel="stylesheet" href="styles.css">
    <script>
        function toggleMenu() {
            document.querySelector('.sidebar').classList.toggle('show');
        }

        function showTable() {
            document.querySelector('.results-table').classList.remove('hidden');
        }
    </script>
</head>
<body>
    <div class="menu-toggle" onclick="toggleMenu()">☰</div>
    <div class="sidebar">
        <ul>
            <a href="home.php"><li>Home</li></a>
            <a href="hotels.html"><li>Hotels</li></a>
            <a href="restaurants.html"><li>Restaurants</li></a>
            <a href="shopping.html"><li>Shopping</li></a>
            <a href="things to do.html"><li>Things to do</li></a>
            <a href="events.html"><li>Events</li></a>
            <a href="guideline.html"><li>Guidelines</li></a>
            <a href="history.html"><li>History</li></a>
            <a href="reviews.php"><li>Reviews</li></a>
            <a href="contacts.html"><li>Contacts</li></a>
        </ul>
    </div>

    <div class="container">
        <div class="header">
            <img src="https://images.squarespace-cdn.com/content/5f7c7de712dbbe4d2c21a154/1602771816048-F3U0A7XAMGGAEBOYGRBS/wolfville+logo_transparent+backgroud.png?format=1500w&content-type=image%2Fpng" alt="Wolfville Logo" class="logo">

            <form method="GET" class="mb-3" onsubmit="showTable()">
                <input type="text" name="search" class="form-control" placeholder="Names, Ratings, Address, Categories" value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit" class="btn btn-primary mt-2">Search</button>
            </form>
        </div>

        <div class="welcome-section">
            <div class="container">
                <h1>Welcome to Wolfville Guide</h1>
                <p>Discover the best of Wolfville, Nova Scotia. Whether you're looking for hotels, restaurants, shopping, or exciting things to do, this guide has everything you need.</p>
                <img src="https://parents.acadiau.ca/assets/images/5/WOLF001-786ccf57.jpg" alt="Wolfville Waterfront" style="width:100%; border-radius: 8px;">
            </div>
        </div>

        <?php if ($result): ?>
        <div class="container mt-4 results-table">
            <table class="table table-bordered table-striped">
                <thead class="thead-dark">
                    <tr>
                        <th>Name</th>
                        <th>Ratings</th>
                        <th>Address</th>
                        <th>Category</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (mysqli_num_rows($result) > 0) {
                        while($row = mysqli_fetch_array($result)) {
                            echo "<tr>";
                            echo "<td>" . $row['establishment_name'] . "</td>";
                            echo "<td class='title'>" . $row['rating'] .  "</td>";
                            echo "<td>" . $row['establishment_address'] .  "</td>";
                            echo "<td>" . $row['category'] .  "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>No results found</td></tr>";
                    }

                    // Free result set
                    mysqli_free_result($result);
                    mysqli_close($con);
                    ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>