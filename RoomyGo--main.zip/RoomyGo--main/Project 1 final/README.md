# RoomyGo 🏠

RoomyGo is a web application that helps students find **rooms** or **roommates** using filters and a swipe-style interface (like a dating app but for housing).

---

## 👩‍💻 Team Members

- **Dhriti** – Swiping feature (frontend + backend), project structure
- **Shekin** – Login, sign-up, MFA, onboarding
- **Drishti** – Filters, categories, and results display

---

## 🎯 Main Features (Planned)

- User login & sign-up with basic validation
- Optional multi-factor authentication (OTP simulation)
- Choose whether you’re looking for a **room** or a **roommate**
- Filters for budget, location, sharing/private, etc.
- Swipe-style interface to **like / dislike** rooms or roommates
- (Optional) Matching logic for mutual roommate interest

---

## 📌 Task Division

### 1. Authentication & Onboarding – **Shekin**

- Login and sign-up pages (UI)
- Form validation (email, password rules, required fields)
- Basic MFA flow (OTP via phone/email *simulation*)
- Onboarding questions:
  - Are you looking for a **room** or **roommate**?
  - Basic preferences (budget, location, etc.)
- Routing user to the correct next step (filters page)

### 2. Filters & Results – **Drishti**

- Filter pages:
  - Filters for **rooms**
  - Filters for **roommates**
- Implementing filter fields (location, budget, sharing/private, gender, etc.)
- Calling backend to get filtered results
- Showing filtered results in a simple list/grid before swiping
- Helping design the database schema (rooms, roommates, basic profiles)

### 3. Swiping Feature – **Dhriti**

- Designing the swipe card UI (image, rent, location, roommate details)
- Implementing **like / dislike** buttons (and later swipe gestures)
- Backend APIs:
  - `GET /api/rooms/next` or `GET /api/roommates/next`
  - `POST /api/swipe` to save likes/dislikes
- Saving swipes in the database (`Swipes` table)
- Handling “no more results left” message
- (Optional) Match logic + simple matches screen

---

