const express = require("express");
const fs = require("fs");
const cors = require("cors");
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(".")); // serve HTML, CSS, JS

// ⭐ API ROUTES

// 1. Fetch Rooms (from rooms.json)
app.get("/api/rooms", (req, res) => {
  const data = fs.readFileSync("rooms.json", "utf8");
  res.json(JSON.parse(data));
});

// 2. Fetch Roommates (from roommates.json)
app.get("/api/roommates", (req, res) => {
  const data = fs.readFileSync("roommates.json", "utf8");
  res.json(JSON.parse(data));
});

// 3. Save swipe decisions (like / skip)
app.post("/api/swipes", (req, res) => {
  const swipe = req.body;
  fs.appendFileSync("swipes.txt", JSON.stringify(swipe) + "\n");
  res.json({ status: "saved", swipe });
});

// 4. Get all liked (FAVOURITES)
app.get("/api/favourites", (req, res) => {
  const lines = fs.readFileSync("swipes.txt", "utf8")
    .split("\n")
    .filter(Boolean)
    .map(line => JSON.parse(line))
    .filter(swipe => swipe.decision === "like");

  res.json(lines);
});

// Start server
app.listen(PORT, () => {
  console.log(`RoomyGo API running at http://localhost:${PORT}`);
});
