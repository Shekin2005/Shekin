
// routes/roomRoutes.js
const express = require('express');
const router = express.Router();

// load static room data
const roomsData = require('../rooms.json');

// helper: turn "$650 / month" into 650
const getPriceNumber = (priceString) => {
  const match = priceString.match(/\d+/);
  return match ? Number(match[0]) : 0;
};

// GET /api/rooms
// examples:
//   /api/rooms
//   /api/rooms?maxRent=700
//   /api/rooms?minRent=500&maxRent=750
//   /api/rooms?location=Wolfville
router.get('/', (req, res) => {
  const { minRent, maxRent, location } = req.query;

  let filtered = [...roomsData];

  if (location) {
    const loc = location.toLowerCase();
    filtered = filtered.filter((room) =>
      room.location.toLowerCase().includes(loc)
    );
  }

  if (minRent) {
    const min = Number(minRent);
    filtered = filtered.filter(
      (room) => getPriceNumber(room.price) >= min
    );
  }

  if (maxRent) {
    const max = Number(maxRent);
    filtered = filtered.filter(
      (room) => getPriceNumber(room.price) <= max
    );
  }

  res.json(filtered);
});

module.exports = router;
