<?php
$conn = mysqli_connect("localhost", "establishments_user", "passw0rd", "establishments_db");
if (!$conn) {
    $errorMessage = "Connection Failed " . mysqli_connect_error();
}

    $reviewNewCount = $_POST['reviewNewCount'];

    $sql = "SELECT * FROM review ORDER BY establishment_name LIMIT $reviewNewCount"; //display reviews cumulative of user button clicks "show more reviews"
    $resultReview = mysqli_query($conn, $sql);

    if (mysqli_num_rows($resultReview) > 0){
        while($row = mysqli_fetch_assoc($resultReview)){
            echo'<div class="review">';
                        echo "<p>";

                        echo "<b>";
                        echo $row ['establishment_name'];
                        echo "</b>";
                        echo "<br>";

                        echo $row['reviews'];
                        echo "<br>";

                        echo $row['star_rating'];
                        echo "<br>";
                        echo "</p>";
                    echo"</div>";
        }
    } else{
        echo "There are no reviews available.";
    }
?>