document.addEventListener("DOMContentLoaded", () => {

  const cardContainer = document.getElementById("cardContainer");
  const skipBtn = document.getElementById("skipBtn");
  const saveBtn = document.getElementById("saveBtn");
  const favBtn = document.getElementById("favBtn");

  let items = [];
  let mode = "rooms";

  // ------------------ DETECT MODE ------------------
  const urlParams = new URLSearchParams(window.location.search);
  mode = urlParams.get("mode") || "rooms";

  const pageTitle = document.getElementById("pageTitle");
  const pageSubtitle = document.getElementById("pageSubtitle");

  if (mode === "roommates") {
    pageTitle.textContent = "Swipe Roommates";
    pageSubtitle.textContent = "Find your perfect roommate match";
  } else {
    pageTitle.textContent = "Swipe Rooms";
    pageSubtitle.textContent = "Swipe to like or skip rooms";
  }

  // ------------------ CLEAN PRICE FUNCTION ------------------
  function cleanPrice(priceText) {
    if (!priceText) return 0;
    return Number(priceText.replace(/[^0-9]/g, ""));
  }

  // ------------------ LOAD DATA ------------------
  // ------------------ LOAD DATA ------------------
async function loadData() {
  try {
    if (mode === "rooms") {
      const res = await fetch("/api/rooms");
      const roomData = await res.json();
      const posted = JSON.parse(localStorage.getItem("advertisedRooms")) || [];
      items = [...roomData, ...posted];

      // ROOM FILTERS
      items = applyRoomFilters(items);

    } else if (mode === "roommates") {
      const res = await fetch("/roommates.json");
      const roommateData = await res.json();
      const posted = JSON.parse(localStorage.getItem("advertiseRoommateRequests")) || [];
      items = [...roommateData, ...posted];

      // ROOMMATE FILTERS
      items = applyRoommateFilters(items);
    }

    createCards();
  } catch (err) {
    console.error("Error loading data:", err);
  }
}

  // ------------------ ROOM FILTER FUNCTION ------------------
  function applyRoomFilters(list) {
    const filters = JSON.parse(localStorage.getItem("roomFilters"));
    if (!filters) return list;

    return list.filter(room => {

      const price = cleanPrice(room.price);

      // --- BUDGET FILTER ---
      if (filters.minBudget && price < filters.minBudget) return false;
      if (filters.maxBudget && price > filters.maxBudget) return false;

      // --- LOCATION ---
      if (filters.location && !room.location?.toLowerCase().includes(filters.location)) {
        return false;
      }

      // --- ROOM TYPE ---
      if (filters.roomType !== "any" &&
          room.type?.toLowerCase() !== filters.roomType.toLowerCase()) {
        return false;
      }

      // --- MAX ROOMMATES ---
      if (filters.roommatesMax !== "any") {
        const r = Number(room.roommates);
        if (r > Number(filters.roommatesMax)) return false;
      }

      return true;
    });
  }

  // ------------------ ROOMMATE FILTER FUNCTION ------------------
  function applyRoommateFilters(list) {
  const filters = JSON.parse(localStorage.getItem("roommateFilters"));
  if (!filters) return list;

  return list.filter(r => {

    // Location filter
    if (filters.loc && !r.location?.toLowerCase().includes(filters.loc)) {
      return false;
    }

    // Gender filter
    if (filters.gender !== "Any" &&
        r.gender?.toLowerCase() !== filters.gender.toLowerCase()) {
      return false;
    }

    // Lifestyle filter
    if (filters.life !== "Any" &&
        r.lifestyle?.toLowerCase() !== filters.life.toLowerCase()) {
      return false;
    }

    // Budget filter
    if (filters.budget && Number(r.budget) > Number(filters.budget)) {
      return false;
    }

    return true;
  });
}

  // ------------------ CREATE SWIPE CARDS ------------------
  function createCards() {
    cardContainer.innerHTML = "";

    if (items.length === 0) {
      cardContainer.innerHTML = "<h2>No matches found</h2>";
      return;
    }

    items.forEach((item, index) => {

      const imgURL =
        item.photo ||
        item.imageUrl ||
        item.image ||
        "https://via.placeholder.com/300";

      const title = mode === "rooms" ? item.title : item.name;

      const priceText = mode === "rooms"
        ? `$${cleanPrice(item.price)}`
        : `Budget: $${item.budget}`;

      const desc =
        item.description
          ? item.description.substring(0, 55) + "..."
          : (item.personality || "No description available");

      const card = document.createElement("div");
      card.classList.add("card");
      card.dataset.index = index;

      card.innerHTML = `
        <div class="card-content">
          <img src="${imgURL}" class="room-image">
          <h2>${title}</h2>
          <p>${item.location || ""}</p>
          <h3 class="price">${priceText}</h3>
          <p>${desc}</p>
        </div>
      `;

      cardContainer.appendChild(card);
      enableDrag(card);
    });
  }

  // ------------------ GET TOP CARD ------------------
  function getTopCard() {
    const cards = document.querySelectorAll(".card");
    return cards[cards.length - 1];
  }

  // ------------------ DRAG-TO-SWIPE ------------------
  function enableDrag(card) {
    let startX = 0;
    let currentX = 0;
    let dragging = false;

    const onMouseDown = (e) => {
      dragging = true;
      startX = e.clientX;
      card.style.transition = "none";
    };

    const onMouseMove = (e) => {
      if (!dragging) return;
      currentX = e.clientX - startX;
      card.style.transform =
        `translateX(${currentX}px) rotate(${currentX / 20}deg)`;
    };

    const onMouseUp = () => {
      if (!dragging) return;
      dragging = false;

      card.style.transition = "0.3s ease";

      if (currentX > 120) return performSwipe("like");
      if (currentX < -120) return performSwipe("skip");

      card.style.transform = "translateX(0) rotate(0)";
    };

    card.addEventListener("mousedown", onMouseDown);
    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup", onMouseUp);
  }

  // ------------------ SWIPE ANIMATION ------------------
  function performSwipe(direction) {
    const card = getTopCard();
    if (!card) return;

    const index = Number(card.dataset.index);
    const item = items[index];

    const movement = direction === "like" ? 1400 : -1400;
    const rotate = direction === "like" ? 18 : -18;

    card.style.transform = `translateX(${movement}px) rotate(${rotate}deg)`;
    card.style.opacity = "0";

    setTimeout(() => {

      if (direction === "like") saveItem(item);

      card.remove();

      if (!document.querySelector(".card")) {
        cardContainer.innerHTML = "<h2>No more matches!</h2>";
      }

    }, 260);
  }

  // ------------------ SAVE TO FAVOURITES ------------------
  function saveItem(item) {
    let saved = JSON.parse(localStorage.getItem("savedItems")) || [];

    const imgURL =
      item.photo ||
      item.imageUrl ||
      item.image ||
      "https://via.placeholder.com/300";

    saved.push({
      ...item,
      imageUrl: imgURL,
      mode: mode
    });

    localStorage.setItem("savedItems", JSON.stringify(saved));
  }

  // ------------------ BUTTON ACTIONS ------------------
  skipBtn.addEventListener("click", () => performSwipe("skip"));
  saveBtn.addEventListener("click", () => performSwipe("like"));
  favBtn.addEventListener("click", () => window.location.href = "favourites.html");

  loadData();
});
