const express = require("express");
const fs = require("fs");
const path = require("path");
const cors = require("cors");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static("."));

// ---------------------- LOAD ROOMS FROM rooms.json ----------------------
app.get("/api/rooms", (req, res) => {
  const filePath = path.join(__dirname, "rooms.json");

  fs.readFile(filePath, "utf8", (err, data) => {
    if (err) {
      console.error("Error reading rooms.json:", err);
      return res.status(500).json({ error: "Server error" });
    }
    const rooms = JSON.parse(data);
    res.json(rooms);
  });
});

// ---------------------- SAVE SWIPES (OPTIONAL) ----------------------
app.post("/api/swipes", (req, res) => {
  const swipe = req.body;
  fs.appendFileSync("swipes.txt", JSON.stringify(swipe) + "\n");
  res.json({ status: "saved" });
});

// ---------------------- START SERVER ----------------------
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
