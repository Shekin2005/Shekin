document.addEventListener("DOMContentLoaded", () => {
  const savedList = document.getElementById("savedList");
  const roomsBtn = document.getElementById("roomsBtn");
  const roommatesBtn = document.getElementById("roommatesBtn");

  const detailsModal = document.getElementById("detailsModal");
  const modalContent = document.getElementById("modalContent");

  const chatModal = document.getElementById("chatModal");
  const chatContent = document.getElementById("chatContent");

  // ================================
  // LOAD SAVED ITEMS
  // ================================
  let savedItems = JSON.parse(localStorage.getItem("savedItems")) || [];

  // Ensure each item has a "type"
  savedItems = savedItems.map((item) => {
    if (!item.type) {
      item.type = item.price ? "rooms" : "roommates";
    }
    return item;
  });
  localStorage.setItem("savedItems", JSON.stringify(savedItems));

  let activeTab = "rooms";
  displayList();

  roomsBtn.addEventListener("click", () => {
    activeTab = "rooms";
    roomsBtn.classList.add("active");
    roommatesBtn.classList.remove("active");
    displayList();
  });

  roommatesBtn.addEventListener("click", () => {
    activeTab = "roommates";
    roommatesBtn.classList.add("active");
    roomsBtn.classList.remove("active");
    displayList();
  });

  // ================================
  // DISPLAY SAVED ITEMS
  // ================================
  function displayList() {
    savedList.innerHTML = "";

    const filtered = savedItems.filter((item) => item.type === activeTab);

    if (filtered.length === 0) {
      savedList.innerHTML = `<p style="color:#550033; padding:20px; font-size:18px;">No saved ${activeTab} yet.</p>`;
      return;
    }

    filtered.forEach((item, index) => {
      const imgURL =
        item.imageUrl || item.photo || "https://via.placeholder.com/150";

      let cleanPrice = "";
      if (item.price) {
        cleanPrice = String(item.price)
          .replace(/\/\s*month/gi, "")
          .replace("$", "")
          .trim();
      }

      const card = document.createElement("div");
      card.classList.add("saved-card");

      card.innerHTML = `
        <img src="${imgURL}" alt="Listing">

        <div class="info">
          <h2>${item.title || item.name}</h2>
          <p>${item.location || "Location not available"}</p>

          ${
            item.type === "rooms"
              ? `<p class="price">Price: $${cleanPrice} / month</p>`
              : `<p class="price">Budget: $${item.budget}</p>
                 <p class="sub-info">${item.gender}, ${item.age} yrs • ${item.lifestyle}</p>
                 <p class="sub-info">${item.cleanliness} • ${item.schedule}</p>`
          }

          <p>${(item.description || item.personality || "No description").substring(0, 60)}...</p>
        </div>

        <div class="icons">
          <i class="fa-solid fa-comment chat-icon" data-index="${index}"></i>
          <i class="fa-solid fa-share-nodes share-icon" data-index="${index}"></i>
          <i class="fa-solid fa-trash delete-icon" data-index="${index}"></i>
        </div>
      `;

      // Card click → open details
      card.addEventListener("click", () => {
        openDetails(item);
      });

      savedList.appendChild(card);
    });

    attachIconEvents();
  }

  // ================================
  // ICON EVENTS (DELETE / SHARE / CHAT)
  // ================================
  function attachIconEvents() {
    // Delete
    document.querySelectorAll(".delete-icon").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const index = btn.dataset.index;
        savedItems.splice(index, 1);
        localStorage.setItem("savedItems", JSON.stringify(savedItems));
        displayList();
      });
    });

    // Share
    document.querySelectorAll(".share-icon").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const index = btn.dataset.index;
        shareItem(savedItems[index]);
      });
    });

    // Chat
    document.querySelectorAll(".chat-icon").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const index = btn.dataset.index;
        openChat(savedItems[index]);
      });
    });
  }

  // ================================
  // SHARE ITEM
  // ================================
  function shareItem(item) {
    const text = `${item.title || item.name}
${item.location || ""}
${item.price ? "$" + item.price : "Budget: $" + item.budget}

${item.description || item.personality || ""}`;

    if (navigator.share) {
      navigator.share({ title: "RoomyGo Listing", text });
    } else {
      navigator.clipboard.writeText(text);
      alert("Copied to clipboard!");
    }
  }

  // ================================
  // OPEN DETAILS MODAL
  // ================================
  function openDetails(item) {
    const imgURL =
      item.imageUrl || item.photo || "https://via.placeholder.com/400";

    let cleanPrice = "";
    if (item.price) {
      cleanPrice = String(item.price)
        .replace(/\/\s*month/gi, "")
        .replace("$", "")
        .trim();
    }

    const isRoom = item.type === "rooms";

    const roomExtra = `
      <div class="extra-box">
        <h3>📌 Extra Details</h3>
        <p><b>Roommates:</b> ${item.roommates || "Not specified"}</p>
        <p><b>Amenities:</b> Heating, WiFi, kitchen access, laundry</p>
        <p><b>Safety:</b> Secure area, smoke detectors</p>
        <p><b>Landlord Replies:</b> Usually within 2 hours</p>
      </div>
    `;

    const roommateExtra = `
      <div class="extra-box">
        <h3>👤 About ${item.name}</h3>
        <p><b>Age:</b> ${item.age}</p>
        <p><b>Gender:</b> ${item.gender}</p>
        <p><b>Program:</b> ${item.program}</p>
        <p><b>Budget:</b> $${item.budget}</p>
        <p><b>Lifestyle:</b> ${item.lifestyle}</p>
        <p><b>Personality:</b> ${item.personality}</p>
        <p><b>Cleanliness:</b> ${item.cleanliness}</p>
        <p><b>Schedule:</b> ${item.schedule}</p>
        <p><b>Hobbies:</b> ${item.hobbies}</p>
        <p><b>Preferred Roommate:</b> ${item.preferredRoommate}</p>
      </div>
    `;

    modalContent.innerHTML = `
      <img src="${imgURL}" alt="Details">

      <h2 class="detail-title">${item.title || item.name}</h2>
      <p class="detail-location">${item.location || ""}</p>

      ${
        isRoom
          ? `<p class="detail-price">$${cleanPrice} / month</p>`
          : `<p class="detail-price">Budget: $${item.budget}</p>`
      }

      <p class="detail-desc">${item.description || item.personality || ""}</p>

      ${isRoom ? roomExtra : roommateExtra}

      <div class="contact-box">
        <h3>📞 Contact</h3>
        <button class="contact-btn" onclick="window.location.href='mailto:${item.email || ""}'">Email</button>
        <button class="contact-btn" onclick="window.location.href='tel:${item.phone || ""}'">Call</button>
        <button class="contact-btn" onclick="window.location.href='https://wa.me/${(item.phone || "").replace(/\D/g, "")}'">WhatsApp</button>
      </div>

      <button class="close-btn" onclick="document.getElementById('detailsModal').style.display='none'">
        Close
      </button>
    `;

    detailsModal.style.display = "flex";
  }

  // ================================
  // OPEN CHAT MODAL
  // ================================
  function openChat(item) {
    chatContent.innerHTML = `
      <h2>Chat with ${item.name || item.title}</h2>

      <div class="chat-window">
        <div class="msg received">Hi! This is a demo chat 😄</div>
      </div>

      <div class="chat-input-box">
        <input type="text" placeholder="Type a message..." id="chatInput">
        <button onclick="sendChatMessage()">Send</button>
      </div>

      <button class="close-btn" onclick="document.getElementById('chatModal').style.display='none'">
        Close
      </button>
    `;

    chatModal.style.display = "flex";
  }
});

// ================================
// GLOBAL CHAT SEND FUNCTION
// ================================
function sendChatMessage() {
  const input = document.getElementById("chatInput");
  const text = input.value.trim();
  if (!text) return;

  const chatWindow = document.querySelector(".chat-window");
  const msg = document.createElement("div");
  msg.classList.add("msg", "sent");
  msg.textContent = text;

  chatWindow.appendChild(msg);
  input.value = "";
}
