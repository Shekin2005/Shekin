// models/Room.js
const mongoose = require('mongoose');

const roomSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    description: String,
    city: { type: String, required: true },
    rent: { type: Number, required: true },
    roomType: { type: String, enum: ['private', 'shared', 'studio'], default: 'private' },
    genderPreference: { type: String, enum: ['any', 'male', 'female'], default: 'any' },
    amenities: [String],          // e.g. ["wifi", "laundry"]
    furnished: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Room', roomSchema);
