// server.js – RoomyGo simple API using rooms.json
const express = require('express');
const cors = require('cors');
const roomsData = require('./rooms.json');

const app = express();
app.use(cors());
app.use(express.json());

// Helper: convert "$650 / month" → 650
const getPriceNumber = (priceString) => {
  const match = priceString.match(/\d+/);
  return match ? Number(match[0]) : 0;
};

// Root route
app.get('/', (req, res) => {
  res.send('RoomyGo Rooms API is running v2');
});

// GET /api/rooms
// Supports filters like:
//   /api/rooms
//   /api/rooms?maxRent=700
//   /api/rooms?location=Wolfville
//   /api/rooms?location=Wolfville&maxRent=700
app.get('/api/rooms', (req, res) => {
  const { minRent, maxRent, location } = req.query;

  let filtered = [...roomsData];

  if (location) {
    const loc = location.toLowerCase();
    filtered = filtered.filter((room) =>
      room.location.toLowerCase().includes(loc)
    );
  }

  if (minRent) {
    const min = Number(minRent);
    filtered = filtered.filter(
      (room) => getPriceNumber(room.price) >= min
    );
  }

  if (maxRent) {
    const max = Number(maxRent);
    filtered = filtered.filter(
      (room) => getPriceNumber(room.price) <= max
    );
  }

  res.json(filtered);
});

const PORT = 5001; // use 5001 since 5000 was busy
app.listen(PORT, () => {
  console.log(`🚀 RoomyGo API listening on port ${PORT}`);
});
