document.addEventListener("DOMContentLoaded", () => {

let rooms = [];
let currentType = "rooms"; // default

async function loadData() {
  const params = new URLSearchParams(window.location.search);
  currentType = params.get("type") || "rooms";

  const endpoint = currentType === "roommates"
    ? "/api/roommates"
    : "/api/rooms";

  try {
    const res = await fetch(endpoint);
    rooms = await res.json();
    buildCards();
  } catch (err) {
    console.error("Failed to load data:", err);
  }
}

const container = document.getElementById("cardContainer");
const skipBtn = document.getElementById("skipBtn");
const saveBtn = document.getElementById("saveBtn");

let isDragging = false;
let startX = 0;
let currentCard = null;

// ---------------- BUILD CARDS ----------------
function buildCards() {
  container.innerHTML = "";

  for (let i = rooms.length - 1; i >= 0; i--) {
    const item = rooms[i];
    const card = document.createElement("div");
    card.className = "card";
    card.dataset.roomId = item.id;

    const imgDiv = document.createElement("div");
    imgDiv.className = "card-image";
    imgDiv.style.backgroundImage = `url(${item.imageUrl})`;

    const content = document.createElement("div");
    content.className = "card-content";

    const titleEl = document.createElement("h2");
    titleEl.textContent =
      currentType === "roommates" ? item.name : item.title;

    const locationEl = document.createElement("p");
    locationEl.textContent = item.location || "";

    const priceOrAgeEl = document.createElement("p");
    priceOrAgeEl.style.color = "#117733";
    priceOrAgeEl.textContent =
      currentType === "roommates" ? `Age: ${item.age}` : item.price;

    const metaEl = document.createElement("p");
    metaEl.textContent =
      item.roommates || item.program || "";

    const descEl = document.createElement("p");
    descEl.textContent = item.description;

    content.append(titleEl, locationEl, priceOrAgeEl, metaEl, descEl);
    card.append(imgDiv, content);

    container.appendChild(card);

    card.addEventListener("pointerdown", (e) => onPointerDown(e.clientX));
    window.addEventListener("pointermove", (e) => onPointerMove(e.clientX));
    window.addEventListener("pointerup", (e) => onPointerUp(e.clientX));
  }
}

// ------------------- SWIPE LOGIC -------------------

function getTopCard() {
  return container.querySelector(".card:last-child");
}

function onPointerDown(x) {
  currentCard = getTopCard();
  if (!currentCard) return;
  isDragging = true;
  startX = x;
  currentCard.style.transition = "none";
}

function onPointerMove(x) {
  if (!isDragging || !currentCard) return;
  const deltaX = x - startX;
  currentCard.style.transform =
    `translateX(${deltaX}px) rotate(${deltaX / 10}deg)`;
}

function onPointerUp(x) {
  if (!isDragging || !currentCard) return;
  const deltaX = x - startX;
  handleSwipe(deltaX);
  isDragging = false;
}

function handleSwipe(deltaX) {
  const threshold = 80;
  if (Math.abs(deltaX) > threshold) {
    const dir = deltaX > 0 ? "like" : "skip";
    performSwipe(dir);
  } else {
    currentCard.style.transition = ".3s";
    currentCard.style.transform = "translateX(0) rotate(0)";
  }
}

function performSwipe(decision) {
  const card = currentCard;
  const roomId = card.dataset.roomId;

  const direction = decision === "like" ? 1 : -1;

  card.style.transition = ".4s ease";
  card.style.transform =
    `translateX(${direction * 1000}px) rotate(${direction * 45}deg)`;
  card.style.opacity = "0";

  setTimeout(() => {
    card.remove();
    saveSwipe(roomId, decision);
  }, 350);
}

// ---------------- SAVE SWIPE -------------------
async function saveSwipe(roomId, decision) {
  try {
    await fetch("/api/swipes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ roomId, decision })
    });
  } catch (err) {
    console.error("Error saving:", err);
  }
}

// ---------------- BUTTONS -------------------
skipBtn.addEventListener("click", () => {
  currentCard = getTopCard();
  if (currentCard) performSwipe("skip");
});

saveBtn.addEventListener("click", () => {
  currentCard = getTopCard();
  if (currentCard) performSwipe("like");
});

loadData();

}); // END DOMContentLoaded
